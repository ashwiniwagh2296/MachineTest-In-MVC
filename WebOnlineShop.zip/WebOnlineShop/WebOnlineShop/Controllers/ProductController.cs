﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebOnlineShop.Models;
using WebOnlineShop.AppCode.BAL;
using System.Data;
using PagedList;
using PagedList.Mvc;


namespace WebOnlineShop.Controllers
{
    public class ProductController : Controller
    {
        ProductBAL objProBal = new ProductBAL();
        CategoryBAl objcatbal = new CategoryBAl();
        // GET: Product
        public ActionResult Index(int page = 1)
        {
            int recordsPerPage = 10;
            DataTable dt = objProBal.ReadProduct();
            DataTable dtcat = objcatbal.Readcategory();
            List<ProductModel> objProModel = new List<ProductModel>();
            int count = 0;
            foreach (DataRow item in dt.Rows)
            {
                count++;
                   ProductModel objPModel = new ProductModel();
                objPModel.SerialNum = count;
                objPModel.ProductId = Convert.ToInt16(item["ProductId"].ToString());
                objPModel.ProductName = item["ProductName"].ToString();
                objPModel.CategoryId = item["CategoryId"].ToString()!="" && item["CategoryId"].ToString() != null ? Convert.ToInt16(item["CategoryId"].ToString()):0;
                if (objPModel.CategoryId != 0)
                {
                    DataRow[] dr = dtcat.Select("CategoryId = '" + objPModel.CategoryId + "'");
                    objPModel.CategoryName = dr[0]["CategoryName"].ToString();
                }
                else
                {
                    objPModel.CategoryName = "";
                }
               
                objProModel.Add(objPModel);

            }
            var list = objProModel.ToList().ToPagedList(page, recordsPerPage);
            return View(list);
           
        }[HttpGet]
        public ActionResult AddProduct()
        {
            DataTable dtcat = objcatbal.Readcategory();
            ViewBag.ListItem = ToSelectList(dtcat, "CategoryId", "CategoryName"); 
            return View();
        }
        [HttpPost]
        public ActionResult AddProduct(ProductModel objProduct)
        {
            objProBal.addProduct(objProduct.ProductName, objProduct.CategoryId);
            return RedirectToAction("Index");
           
        }
        [HttpGet]
        public ActionResult DeleteProduct(int id)
        {
            objProBal.DeleteProduct(id);
            return RedirectToAction("Index");
          //  return View();
        }
        
        public ActionResult ReadProduct()
        {
            return View();
        }
        [NonAction]
        public SelectList ToSelectList(DataTable table, string valueField, string textField)
        {
            List<SelectListItem> list = new List<SelectListItem>();

            foreach (DataRow row in table.Rows)
            {
                list.Add(new SelectListItem()
                {
                    Text = row[textField].ToString(),
                    Value = row[valueField].ToString()
                });
            }

            return new SelectList(list, "Value", "Text");
        }
        [HttpGet]
        public ActionResult UpdateProduct(int id)
        {
            DataTable dt = objProBal.ReadProduct();
            DataRow[] dr = dt.Select("ProductId = '" + id + "'");
            ProductModel objPModel = new ProductModel();
            objPModel.ProductId = Convert.ToInt32(dr[0]["ProductId"]);
            objPModel.ProductName = dr[0]["ProductName"].ToString();
            objPModel.CategoryId = dr[0]["CategoryId"].ToString() != "" && dr[0]["CategoryId"].ToString() != null ? Convert.ToInt16(dr[0]["CategoryId"].ToString()) : 0;
            DataTable dtcat = objcatbal.Readcategory();
            if (objPModel.CategoryId != 0)
            {
                DataRow[] drcat = dtcat.Select("CategoryId = '" + objPModel.CategoryId + "'");
                objPModel.CategoryName = drcat[0]["CategoryName"].ToString();
            }
            else
            {
                objPModel.CategoryName = "";
            }
            ViewBag.ListItem = ToSelectList(dtcat, "CategoryId", "CategoryName");
            return View(objPModel);
        }
        [HttpPost]
        public ActionResult UpdateProduct(int id , ProductModel objProduct)
        {
            try
            {
                objProBal.UpdateProduct(id, objProduct.ProductName, objProduct.CategoryId);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {

               
            }
            return View();

        }
     

    }
}