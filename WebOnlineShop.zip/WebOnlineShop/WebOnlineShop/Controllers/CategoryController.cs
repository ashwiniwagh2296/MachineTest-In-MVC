﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebOnlineShop.Models;
using WebOnlineShop.AppCode.BAL;
using System.Data;

namespace WebOnlineShop.Controllers
{
    public class CategoryController : Controller
    {

        CategoryBAl objcatbal = new CategoryBAl();
        // GET: Categoary
        public ActionResult Index()
        {
           DataTable dt= objcatbal.Readcategory();
            List<CategoryModel> objCatModel = new List<CategoryModel>();
              int count = 0;
           
            foreach (DataRow item in dt.Rows)
            {
                count++;
                CategoryModel objCModel = new CategoryModel();
                objCModel.SerialNum = count;
                objCModel.CategoryId =Convert.ToInt16( item["CategoryId"].ToString());
                objCModel.CategoryName = item["CategoryName"].ToString();
                objCatModel.Add(objCModel);


            }

            return View(objCatModel);
        }
        [HttpGet]
        public ActionResult AddCategory()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCategory(CategoryModel objCategory)
        {
            objcatbal.addcategory(objCategory.CategoryName);
            return View();
        }
        [HttpGet]
        public ActionResult DeleteCategory(int id)
        {
            objcatbal.Deletecategory(id);
            return RedirectToAction("Index");
          // return View();
        }

        [HttpGet]
        public ActionResult UpdateCategory(int id)
        {
            DataTable dtcat = objcatbal.Readcategory();
            DataRow[] dr = dtcat.Select("CategoryId = '" + id + "'");
            CategoryModel objCModel = new CategoryModel();
            objCModel.CategoryName = dr[0]["CategoryName"].ToString();
            return View(objCModel);

            
        }
        [HttpPost]
        public ActionResult UpdateCategory(int id, CategoryModel objCategory)
        {
            try
            {
                objcatbal.UpdateCategory( objCategory.CategoryName,id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {


            }
            return View();
        }
        public ActionResult ReadCategory()
        {
            return View();
        }
    }
}